<?php
/*
 * Theme Name: Scratch
 * Author: Amit Moreno
 * Author URI: http://www.amitmoreno.com/
 * Version: 0.0.1
 * Text Domain: scratch
 */

include 'theme-settings.php';
include 'theme-scripts.php';
include 'theme-menus.php';