// jQuery fix for Wordpress
jQuery(function($){
});