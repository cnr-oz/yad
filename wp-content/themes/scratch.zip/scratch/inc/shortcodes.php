<?php

/*
 * Typography
 * 
 * since 1.0.0
 */
include 'shortcodes/mark.php';
include 'shortcodes/small.php';
/*
 * Bootstrap shortcodes
 * 
 * since 0.0.1
 */
include 'shortcodes/bootstrap-jumbotron.php';
include 'shortcodes/bootstrap-btn.php';
include 'shortcodes/bootstrap-panel.php';
include 'shortcodes/bootstrap-col.php';
include 'shortcodes/bootstrap-row.php';
include 'shortcodes/bootstrap-lead.php';

